Hi,
on my homepage you will find a transparent (.png) high-voltage plate 700x700 px.

thank you.
Stephan W.
www.3d-hobby-art.de