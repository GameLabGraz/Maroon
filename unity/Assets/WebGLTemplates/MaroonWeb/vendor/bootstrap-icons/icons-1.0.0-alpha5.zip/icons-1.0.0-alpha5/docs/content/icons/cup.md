---
title: Cup
layout: icon
categories:
  - Real world
tags:
  - mug
---
