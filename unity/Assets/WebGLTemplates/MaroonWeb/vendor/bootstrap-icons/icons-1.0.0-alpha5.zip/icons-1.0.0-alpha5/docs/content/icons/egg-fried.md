---
title: Egg fried
categories:
  - Real world
tags:
  - food
---
