---
title: Check2 circle
layout: icon
categories:
  - UI and keyboard
tags:
  - checkmark
  - todo
  - select
  - done
  - checkbox
---
