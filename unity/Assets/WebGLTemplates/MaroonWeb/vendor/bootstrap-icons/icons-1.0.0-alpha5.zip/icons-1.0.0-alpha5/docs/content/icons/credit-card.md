---
title: Credit card
categories:
  - Real world
tags:
  - debit
  - card
  - payment
---
