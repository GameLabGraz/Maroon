---
title: Clipboard minus
categories:
  - Real world
tags:
  - copy
  - paste
---
