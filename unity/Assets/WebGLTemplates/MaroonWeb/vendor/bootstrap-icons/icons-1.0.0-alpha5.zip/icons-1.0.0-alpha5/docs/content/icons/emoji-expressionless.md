---
title: Emoji expressionless
layout: icon
categories:
  - Emoji
tags:
  - emoticon
  - neutral
  - unphased
---
