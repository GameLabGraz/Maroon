---
title: Box arrow left
categories:
  - Box arrows
tags:
  - arrow
---
