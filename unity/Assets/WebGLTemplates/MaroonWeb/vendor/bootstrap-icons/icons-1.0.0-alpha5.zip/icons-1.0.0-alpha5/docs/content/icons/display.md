---
title: Display
categories:
  - Devices
tags:
  - monitor
  - external
---
