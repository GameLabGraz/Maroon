---
title: Alert circle fill
categories:
  - Alerts, warnings, and signs
tags:
  - alert
  - warning
---
